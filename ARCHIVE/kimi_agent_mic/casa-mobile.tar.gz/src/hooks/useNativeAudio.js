/**
 * Native Audio Hook — @speechmatics/expo-two-way-audio
 *
 * Streams raw PCM from the microphone and plays PCM responses using
 * native iOS/Android audio APIs (no browser audio).
 *
 * The module delivers microphone data at 16 kHz; OpenAI Realtime expects
 * 24 kHz, so we upsample before sending. Incoming AI audio is 24 kHz, so
 * we downsample before playback.
 */
import { useRef, useCallback, useEffect } from 'react';
import {
  initialize,
  requestMicrophonePermissionsAsync,
  toggleRecording,
  playPCMData,
  addExpoTwoWayAudioEventListener,
  tearDown,
} from '@speechmatics/expo-two-way-audio';
import { resamplePCM16 } from '../utils/resamplePCM16';

const MIC_RATE = 16000;
const OPENAI_RATE = 24000;

export function useNativeAudio() {
  const onAudioChunkRef = useRef(null);
  const isRecordingRef = useRef(false);
  const micSubRef = useRef(null);

  // Initialize native audio once on mount and listen for mic data.
  useEffect(() => {
    let mounted = true;

    const setup = async () => {
      try {
        await initialize();
        const { status } = await requestMicrophonePermissionsAsync();
        if (status !== 'granted') {
          console.warn('[NativeAudio] Microphone permission not granted');
          return;
        }

        micSubRef.current = addExpoTwoWayAudioEventListener(
          'onMicrophoneData',
          (event) => {
            if (!isRecordingRef.current || !onAudioChunkRef.current) return;
            // event.data is 16 kHz PCM16 LE; upsample to OpenAI's 24 kHz.
            const pcm24k = resamplePCM16(event.data, MIC_RATE, OPENAI_RATE);
            onAudioChunkRef.current(pcm24k);
          }
        );
      } catch (err) {
        console.error('[NativeAudio] Setup error:', err);
      }
    };

    setup();

    return () => {
      mounted = false;
      micSubRef.current?.remove();
      tearDown().catch(() => {});
    };
  }, []);

  const startRecording = useCallback(async (onAudioChunk) => {
    onAudioChunkRef.current = onAudioChunk;
    isRecordingRef.current = true;
    toggleRecording(true);
  }, []);

  const stopRecording = useCallback(async () => {
    isRecordingRef.current = false;
    toggleRecording(false);
  }, []);

  const playAudio = useCallback(async (pcm16Data) => {
    // OpenAI sends 24 kHz PCM; downsample to 16 kHz for the native module.
    const pcm16k = resamplePCM16(pcm16Data, OPENAI_RATE, MIC_RATE);
    playPCMData(pcm16k);
  }, []);

  // The native module has no separate "stop playback" API; teardown would
  // also kill the mic. We rely on response.cancel from the Realtime client
  // to stop new audio arriving.
  const stopPlayback = useCallback(async () => {
    // no-op: managed by native AudioTrack queue + interrupt from OpenAI.
  }, []);

  return {
    startRecording,
    stopRecording,
    playAudio,
    stopPlayback,
  };
}
